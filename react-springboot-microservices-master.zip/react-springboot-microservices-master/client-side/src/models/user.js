export class User {
  constructor(username, password, name, id){
    this.username = username;
    this.password = password;
    this.name = name;
    this.id = id;
  }
}
