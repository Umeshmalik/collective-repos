package com.sha.microserviceusermanagement.model;

public enum Role {
    USER,
    ADMIN
}
