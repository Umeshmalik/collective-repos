# Gateway-Service

This project is a Spring Boot, Spring Zuul project.

## Development server

Run `Gateway-Service Main class` for a dev server. Navigate to `http://localhost:8765/`. The app will automatically reload if you change any of the source files.

## Build

Run `gradlew clean build`

java -Djava.security.egd=file:/dev/./urandom -jar app.jar
