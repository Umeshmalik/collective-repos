package me.ktkim.blog.common.util;

public enum AuthProvider {
    local,
    facebook,
    google,
    github
}
