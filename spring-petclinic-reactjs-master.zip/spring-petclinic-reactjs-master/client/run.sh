#! /bin/bash

PORT=4444 npm start
