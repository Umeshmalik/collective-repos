import * as React from 'react';

export default () => <h3>The requested page has not been found.</h3>;
