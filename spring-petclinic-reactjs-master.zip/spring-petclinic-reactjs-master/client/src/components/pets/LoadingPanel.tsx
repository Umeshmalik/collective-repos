import * as React from 'react';

export default () => (
  <span>
    <h2>Pet</h2>
    <form className='form-horizontal' method='POST'>
      <div className='form-group has-feedback'>
        Loading...
      </div>
    </form>
  </span>
);
