import * as React from 'react';
declare module 'react-datepicker' {
  export class ReactDatePicker extends React.Component<any, {}> { }
}