declare module "react-hot-loader" {
  export  var AppContainer: any;
}